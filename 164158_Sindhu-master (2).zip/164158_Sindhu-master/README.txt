This is not easy....!

------